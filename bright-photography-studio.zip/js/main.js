(() => {
  const root = document.documentElement;
  const themeButton = document.getElementById('theme-toggle');
  const menuButton = document.getElementById('menu-toggle');
  const nav = document.getElementById('nav');
  const form = document.getElementById('contact-form');
  const status = document.getElementById('form-status');
  const year = document.getElementById('year');

  if (year) year.textContent = new Date().getFullYear();

  if (themeButton) {
    const updateThemeButton = () => {
      const isDark = root.dataset.theme === 'dark';
      themeButton.setAttribute('aria-pressed', String(isDark));
      themeButton.setAttribute('aria-label', isDark ? 'Switch to light theme' : 'Switch to dark theme');
    };
    updateThemeButton();
    themeButton.addEventListener('click', () => {
      const nextTheme = root.dataset.theme === 'dark' ? 'light' : 'dark';
      root.dataset.theme = nextTheme;
      try { localStorage.setItem('bright-theme', nextTheme); } catch (_) {}
      updateThemeButton();
    });
  }

  if (menuButton && nav) {
    menuButton.addEventListener('click', () => {
      const open = menuButton.getAttribute('aria-expanded') !== 'true';
      menuButton.setAttribute('aria-expanded', String(open));
      menuButton.setAttribute('aria-label', open ? 'Close navigation' : 'Open navigation');
      nav.classList.toggle('is-open', open);
    });
    nav.querySelectorAll('a').forEach(link => link.addEventListener('click', () => {
      nav.classList.remove('is-open');
      menuButton.setAttribute('aria-expanded', 'false');
      menuButton.setAttribute('aria-label', 'Open navigation');
    }));
    window.addEventListener('resize', () => {
      if (window.innerWidth > 700) {
        nav.classList.remove('is-open');
        menuButton.setAttribute('aria-expanded', 'false');
      }
    });
  }

  if (form) {
    form.addEventListener('submit', event => {
      event.preventDefault();
      if (!form.reportValidity()) return;
      const data = new FormData(form);
      const name = String(data.get('name') || '').trim();
      const email = String(data.get('email') || '').trim();
      const service = String(data.get('service') || '').trim();
      const message = String(data.get('message') || '').trim();
      const subject = encodeURIComponent(`Photography enquiry — ${service}`);
      const body = encodeURIComponent(
        `Hello Bright Photography Studio,\n\nMy name is ${name}.\nEmail: ${email}\nService: ${service}\n\nAbout my idea:\n${message}\n\nThank you!`
      );
      if (status) status.textContent = 'Opening your email app. Review the message and press Send to contact the studio.';
      window.location.href = `mailto:byisihak60@gmail.com?subject=${subject}&body=${body}`;
    });
  }
})();